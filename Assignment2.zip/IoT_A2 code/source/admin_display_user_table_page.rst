Admin's Display User Table page
=================================
*Directory: app/templates/admin/userlist.html*

The admin's user list page is a html page that displays all information possible available in the User 
Table. This information is received from the *users()* function in :ref:`views`. The admin can modify 
the table with the following:

* Delete a specific user on the table, *deleteuser()* is called from :ref:`views`.
