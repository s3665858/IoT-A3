Customer's Booking History page
================================
*Directory: app/templates/customer/bookhistory.html*

The customer's booking history page is a html page that displays all previous bookings of the current 
user. The booking history information is received from *history()* function in :ref:`views`.

