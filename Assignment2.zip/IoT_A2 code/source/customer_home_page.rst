Customer Home Page
=====================
*Directory: app/templates/customer/home.html*

The customer home page is a simple html page that displays a welcome message, 
it contains a panel on the top for customers to redirect to the following pages:

.. toctree::
   :maxdepth: 1

   customer_available_cars_page
   customer_search_car_page
   customer_ongoing_booking_page
   customer_booking_history_page
   customer_google_authentication_page



