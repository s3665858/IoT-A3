Admin's Add Car Page
=======================
*Directory: app/templates/admin/addcar.html*

The admin's add car page is a html page that allows the admin to fill in a form to add a car into the 
Cars table in the database. If all the parameters are filld in correctly, *addcar()* in :ref:`views` will 
add the information of the new car into the Cars table.
