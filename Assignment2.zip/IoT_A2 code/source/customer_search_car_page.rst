Customer's Search Car page
=============================
*Directory: app/templates/customer/searchcar.html*

The customer's search car page is a html page that allows the user to search for cars that matches 
the keyword entered by the user. The user can also choose from different specifications of the car to 
filter the search. The information entered by the user is then received by the *searchcar()* function in 
:ref:`views` which then displays the filtered information after execution.