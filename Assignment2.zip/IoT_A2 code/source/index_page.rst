Index Page
===========
*Directory: app/templates/index.html*

The index page is a simple html page that redirects users to either the 
:ref:`login_page` or the :ref:`register_page`.


