Admin Home Page
================
*Directory: app/templates/admin/home.html*

The admin home page is a simple html page that contains a panel on the top 
for admins to redirect to the following pages:

.. toctree::
   :maxdepth: 1

   admin_display_car_table_page
   admin_add_car_into_table_page
   admin_display_user_table_page



